globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/node_modules_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [
    "static/development/_buildManifest.js",
    "static/development/_ssgManifest.js",
    "static/development/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_10z625~._.js",
    "static/chunks/node_modules_next_dist_compiled_next-devtools_index_0553esy.js",
    "static/chunks/node_modules_next_dist_compiled_react-dom_058-ah~._.js",
    "static/chunks/node_modules_next_dist_compiled_react-server-dom-turbopack_0p3wegg._.js",
    "static/chunks/node_modules_next_dist_compiled_0rpq4pf._.js",
    "static/chunks/node_modules_next_dist_client_0fhqo1d._.js",
    "static/chunks/node_modules_next_dist_115brz8._.js",
    "static/chunks/node_modules_@swc_helpers_cjs_0-4ujiy._.js",
    "static/chunks/_0rqeker._.js",
    "static/chunks/turbopack-_0p44nws._.js"
  ]
};
