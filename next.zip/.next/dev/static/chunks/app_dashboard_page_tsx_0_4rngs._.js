(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/_11krm2v._.js","static/chunks/node_modules_lodash_0vuq0nj._.js","static/chunks/node_modules_recharts_es6_0c9eq36._.js","static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ezz.e5._.js","static/chunks/node_modules_motion-dom_dist_es_0n_wqqr._.js","static/chunks/node_modules_framer-motion_dist_es_129u8xh._.js","static/chunks/node_modules_0r9g5nu._.js"],
    source: "dynamic"
});
