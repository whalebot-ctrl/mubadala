module.exports=[20172,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_markets_route_actions_0v~ysno.js.map