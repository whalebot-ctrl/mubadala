module.exports=[93496,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_kyc-verification_page_actions_0h7uud5.js.map