module.exports=[39554,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_kyc-help_page_actions_0q~scfo.js.map