module.exports=[4286,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_kyc_route_actions_0ayp.m4.js.map