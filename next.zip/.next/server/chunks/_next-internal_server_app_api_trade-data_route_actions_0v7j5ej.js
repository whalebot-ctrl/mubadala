module.exports=[89226,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_trade-data_route_actions_0v7j5ej.js.map