globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/gqFfFjIckn0h2h1HSDPkC/_buildManifest.js",
    "static/gqFfFjIckn0h2h1HSDPkC/_ssgManifest.js",
    "static/gqFfFjIckn0h2h1HSDPkC/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/00gq-v0e07i1q.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/0wi0ebnx_enf8.js",
    "static/chunks/00ilazh50sdzh.js",
    "static/chunks/turbopack-0izro7j06.o84.js"
  ]
};
