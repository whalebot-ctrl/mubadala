:HL["/_next/static/chunks/0.w5~k0rrwgc1.css","style"]
:HL["/_next/static/chunks/03j.x1pr1hwo7.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"gqFfFjIckn0h2h1HSDPkC"}
