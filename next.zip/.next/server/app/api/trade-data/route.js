var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/trade-data/route.js")
R.c("server/chunks/[root-of-the-server]__0dt14bf._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_trade-data_route_actions_0v7j5ej.js")
R.m(55818)
module.exports=R.m(55818).exports
