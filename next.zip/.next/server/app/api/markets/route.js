var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/markets/route.js")
R.c("server/chunks/[root-of-the-server]__0cciqqo._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_markets_route_actions_0v~ysno.js")
R.m(881)
module.exports=R.m(881).exports
