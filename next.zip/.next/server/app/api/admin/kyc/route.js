var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/kyc/route.js")
R.c("server/chunks/[root-of-the-server]__02363~n._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_kyc_route_actions_0ayp.m4.js")
R.m(58741)
module.exports=R.m(58741).exports
