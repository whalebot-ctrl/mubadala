var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/create-user/route.js")
R.c("server/chunks/[root-of-the-server]__0k.mzfh._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_create-user_route_actions_0.rgdxy.js")
R.m(40140)
module.exports=R.m(40140).exports
