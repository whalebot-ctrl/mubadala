var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/signin/route.js")
R.c("server/chunks/[root-of-the-server]__0n~wwrb._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_signin_route_actions_13bajux.js")
R.m(16563)
module.exports=R.m(16563).exports
